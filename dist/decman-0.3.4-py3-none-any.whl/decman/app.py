"""
Module containing the CLI Application.
"""

import argparse
import os
import shutil
import subprocess
import sys
import traceback
import typing

import decman
import decman.config as conf
import decman.error as err
import decman.lib as l
from decman.lib import fpm


def main():
    """
    Main entry for the CLI app
    """

    sys.pycache_prefix = os.path.join(conf.pkg_cache_dir, "python/")

    parser = argparse.ArgumentParser(
        prog="decman",
        description="Declarative package & configuration manager for Arch Linux",
        epilog="See more help at: https://github.com/kiviktnm/decman",
    )

    parser.add_argument(
        "--source", action="store", help="python file containing configuration"
    )
    parser.add_argument(
        "--print",
        "--dry-run",
        action="store_true",
        default=False,
        help="print what would happen as a result of running decman",
    )
    parser.add_argument(
        "--debug", action="store_true", default=False, help="show debug output"
    )
    parser.add_argument(
        "--no-packages",
        action="store_true",
        default=False,
        help="don't upgrade any packages (including foreign packages)",
    )
    parser.add_argument(
        "--no-foreign-packages",
        action="store_true",
        default=False,
        help="don't upgrade foreign packages",
    )
    parser.add_argument(
        "--no-files", action="store_true", default=False, help="don't install any files"
    )
    parser.add_argument(
        "--no-systemd-units",
        action="store_true",
        default=False,
        help="don't enable/disable systemd units",
    )
    parser.add_argument(
        "--no-commands",
        action="store_true",
        default=False,
        help="don't run user specified commands",
    )
    parser.add_argument(
        "--upgrade-devel",
        action="store_true",
        default=False,
        help="upgrade devel packages",
    )
    parser.add_argument(
        "--force-build",
        action="store_true",
        default=False,
        help="force building of packages that are already cached",
    )

    args = parser.parse_args()

    if not _is_root():
        l.print_error("Not running as root. Please run decman as root.")
        sys.exit(1)

    original_wd = os.getcwd()

    try:
        store = l.Store.restore()
    except err.UserFacingError as error:
        l.print_error(error.user_facing_msg)
        for line in traceback.format_exc().splitlines():
            l.print_debug(line)
        sys.exit(1)

    errored = False

    try:
        opts = _set_up(store, args)
        # Override debug_output if cli option is used
        if args.debug:
            conf.debug_output = True
            conf.suppress_command_output = False
        # When print cli option is used, show info output
        if args.print:
            conf.quiet_output = False
        Core(store, opts).run()
    except err.UserFacingError as error:
        l.print_error(error.user_facing_msg)
        for line in traceback.format_exc().splitlines():
            l.print_debug(line)
        errored = True
    except decman.UserRaisedError as user_error:
        l.print_error(f"Error encountered while running the source: {user_error}")
        errored = True

    # Save even when an error has occurred, since this avoids repeating steps like building pkgs.
    try:
        store.save()
    except err.UserFacingError as error:
        l.print_error(error.user_facing_msg)
        for line in traceback.format_exc().splitlines():
            l.print_debug(line)
        errored = True

    os.chdir(original_wd)
    if errored:
        sys.exit(2)


def _set_up(store: l.Store, args):
    source = store.source_file
    source_changed = False
    if args.source is not None:
        source = args.source
        source_changed = True

    if source is None:
        l.print_error(
            "Source was not specified. Please specify a source with the '--source' argument."
        )
        l.print_info("Decman will remember the previously specified source.")
        sys.exit(1)

    if source_changed or not store.allow_running_source_without_prompt:
        l.print_warning(f"Decman will run the file '{source}' as root!")
        l.print_warning(
            "Only proceed if you trust the file completely. The file can also import other files."
        )

        if not l.prompt_confirm("Proceed?", default=False):
            sys.exit(1)

        if l.prompt_confirm("Remember this choice?", default=False):
            store.allow_running_source_without_prompt = True

    source_path = os.path.abspath(source)
    source_dir = os.path.dirname(source_path)
    store.source_file = source_path

    try:
        with open(source_path, "rt", encoding="utf-8") as file:
            content = file.read()
    except OSError as e:
        raise err.UserFacingError(
            f"Failed to read source file '{store.source_file}'."
        ) from e

    os.chdir(source_dir)
    sys.path.append(".")
    exec(content)

    return (
        args.print,
        not args.no_packages,
        not args.no_foreign_packages,
        not args.no_files,
        not args.no_systemd_units,
        not args.no_commands,
        args.upgrade_devel,
        args.force_build,
    )


class Core:
    """
    Contains the main logic of decman.
    """

    def __init__(self, store: l.Store, opts):
        (
            self.only_print,
            self.update_packages,
            self.update_foreign_packages,
            self.update_files,
            self.update_units,
            self.run_commands,
            self.upgrade_devel,
            self.force_build,
        ) = opts

        self.store = store
        self.source = _resolve_source()
        self.pacman = l.Pacman()
        self.systemctl = l.Systemd(store)
        self.fpkg_search = fpm.ExtendedPackageSearch(self.pacman)

        for upkg in self.source.all_user_pkgs():
            self.fpkg_search.add_user_pkg(
                fpm.PackageInfo.from_user_package(upkg, self.pacman)
            )

        self.fpm = fpm.ForeignPackageManager(store, self.pacman, self.fpkg_search)

    def run(self):
        """
        Run the main logic of decman.
        """
        if self.update_units:
            self._disable_units()

        if self.update_files:
            self._create_and_remove_files()

        if self.update_packages:
            self._remove_pkgs()
            self._upgrade_pkgs()
            self._install_pkgs()
            # Offer to remove orphan packages after package operations
            if not self.only_print:
                self._offer_remove_orphans()
                # Optionally clean pacman cache automatically (safer -Sc)
                self._offer_clean_pkg_cache()

            # Optionally ensure niri-qml is installed (AUR or source), controlled by config
            self._ensure_qml_niri()

        if self.update_units:
            self._enable_units()

        if self.run_commands:
            self._run_modules()
            all_enabled_modules = {}
            for mod, version in self.source.all_enabled_modules():
                all_enabled_modules[mod] = version
            # Enabled modules are really only stored for commands,
            # so they can be set only when the commands were exacuted.
            self.store.enabled_modules = all_enabled_modules

    def _disable_units(self):
        to_disable = self.source.units_to_disable(self.store)
        l.print_list("Disabling systemd units:", to_disable)
        if to_disable:
            l.print_info("Disabled systemd units won't be stopped automatically.")
        if not self.only_print:
            self.systemctl.disable_units(to_disable)

        user_units_to_disable = self.source.user_units_to_disable(self.store)
        for user, units in user_units_to_disable.items():
            l.print_list(f"Disabling systemd units for {user}:", units)
            if not self.only_print:
                self.systemctl.disable_user_units(units, user)

    def _remove_pkgs(self):
        currently_installed = self.pacman.get_installed()
        to_remove = self.source.packages_to_remove(currently_installed)
        l.print_list("Removing packages:", to_remove)
        if not self.only_print:
            self.pacman.remove(to_remove)

    def _upgrade_pkgs(self):
        l.print_summary("Upgrading packages.")
        if not self.only_print:
            self.pacman.upgrade()
            # Before handling AUR, ensure requested helper is present if configured
            self._ensure_aur_helper_installed_if_needed()

            # Prefer built-in FPM unless disabled or an AUR helper is preferred and available
            helper_exe = self._resolve_aur_helper_exe()
            if (
                self.update_foreign_packages
                and conf.use_aur_helper_for_aur
                and helper_exe is not None
            ):
                sudo_user = os.environ.get("SUDO_USER")
                if sudo_user and self._can_user_sudo(sudo_user):
                    aur_list = sorted(list(self.source.aur_packages))
                    if aur_list:
                        l.print_summary(
                            f"Ensuring declared AUR packages with {helper_exe} (skips up-to-date):"
                        )
                        l.print_list("AUR packages:", aur_list)
                        self._run_as_user_with_sudo([helper_exe, "-S", "--needed"] + aur_list, sudo_user)
                elif not sudo_user:
                    l.print_warning(
                        "SUDO_USER not set; cannot run the AUR helper as a regular user. Skipping helper-based upgrade."
                    )
                else:
                    l.print_warning(
                        f"User '{sudo_user}' cannot use sudo (not in sudoers or wheel group not enabled). Falling back to FPM."
                    )
            elif conf.enable_fpm and self.update_foreign_packages:
                self.fpm.upgrade(
                    self.upgrade_devel, self.force_build, self.source.ignored_packages
                )

    def _install_pkgs(self):
        currently_installed = self.pacman.get_installed()
        to_install_pacman = self.source.pacman_packages_to_install(currently_installed)
        to_install_fpm = self.source.foreign_packages_to_install(currently_installed)

        l.print_list("Installing pacman packages:", to_install_pacman)

        # fpm prints a summary so no need to print it twice
        if self.only_print:
            l.print_list("Installing foreign packages:", to_install_fpm)

        if not self.only_print:
            self.pacman.install(to_install_pacman)
            if self.update_foreign_packages:
                # Make sure helper exists if configured
                self._ensure_aur_helper_installed_if_needed()
                helper_exe = self._resolve_aur_helper_exe()
                # Split foreign packages to AUR and user packages
                aur_declared = self.source.aur_packages
                aur_to_install = [p for p in to_install_fpm if p in aur_declared]
                user_pkg_to_install = [p for p in to_install_fpm if p not in aur_declared]

                used_yay = False
                if (
                    conf.use_aur_helper_for_aur
                    and helper_exe is not None
                    and aur_to_install
                ):
                    sudo_user = os.environ.get("SUDO_USER")
                    if sudo_user and self._can_user_sudo(sudo_user):
                        l.print_summary(
                            f"Installing declared AUR packages with {helper_exe} (skips up-to-date):"
                        )
                        l.print_list("AUR packages:", aur_to_install)
                        self._run_as_user_with_sudo([helper_exe, "-S", "--needed"] + aur_to_install, sudo_user)
                        used_yay = True
                    elif not sudo_user:
                        l.print_warning(
                            "SUDO_USER not set; cannot run the AUR helper as a regular user. Falling back to decman's builder if enabled."
                        )
                    else:
                        l.print_warning(
                            f"User '{sudo_user}' cannot use sudo (not in sudoers or wheel group not enabled). Falling back to FPM."
                        )

                remaining = user_pkg_to_install + ([] if used_yay else aur_to_install)
                if remaining:
                    if conf.enable_fpm:
                        self.fpm.install(remaining, force=self.force_build)
                    else:
                        # Can't install remaining via fpm; warn the user
                        l.print_warning(
                            "Foreign package installation skipped because both decman FPM is disabled and yay was not used."
                        )

    def _resolve_aur_helper_exe(self) -> typing.Optional[str]:
        """Return the real system AUR helper binary path if available, else None.

        Important: We ignore our own guard wrappers in /usr/local/bin and only
        consider the real binaries in /usr/bin to avoid false positives before
        the helper is actually installed.

        Back-compat: if aur_helper isn't set but use_yay_for_aur_if_available is True,
        prefer yay.
        """
        helper = getattr(conf, "aur_helper", None)
        if helper is None and getattr(conf, "use_yay_for_aur_if_available", False):
            helper = "yay"

        if helper not in ("yay", "paru"):
            return None

        candidate = shutil.which(helper)
        return candidate

    def _can_user_sudo(self, username: str) -> bool:
        """Check if a user can use sudo (has proper sudoers configuration)."""
        try:
            import grp
            import pwd
            # Check if user is in the wheel group
            user_info = pwd.getpwnam(username)
            wheel_gid = grp.getgrnam("wheel").gr_gid
            user_groups = os.getgrouplist(username, user_info.pw_gid)
            if wheel_gid not in user_groups:
                return False
            
            # Check if wheel group is enabled in sudoers
            result = subprocess.run(
                ["grep", "-E", "^%wheel.*ALL.*ALL", "/etc/sudoers"],
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            return result.returncode == 0
        except Exception:  # pylint: disable=broad-except
            return False

    def _run_as_user_with_sudo(self, command: list[str], username: str):
        """Run a command as a specific user using sudo, preserving their ability to sudo.
        
        This is different from decman.prg() which uses setuid() and breaks sudo access.
        """
        try:
            # Use sudo -u to run as the user, which preserves their sudo privileges
            subprocess.run(["sudo", "-u", username] + command, check=True)
        except subprocess.CalledProcessError as e:
            raise err.UserFacingError(
                f"Running user program '{command}' as {username} failed."
            ) from e

    def _ensure_aur_helper_installed_if_needed(self):
        """If a helper is configured but missing, try to install it via FPM (AUR)."""
        helper = getattr(conf, "aur_helper", None)
        if helper is None and getattr(conf, "use_yay_for_aur_if_available", False):
            helper = "yay"

        if helper not in ("yay", "paru"):
            return

        # Only consider the real binary under /usr/bin; ignore our wrappers in /usr/local/bin
        if self._resolve_aur_helper_exe() is not None:
            return

        pkg = getattr(conf, "aur_helper_package", None)
        if pkg is None:
            pkg = "yay-bin" if helper == "yay" else "paru-bin"

        if conf.enable_fpm and self.update_foreign_packages:
            l.print_summary(f"Installing configured AUR helper '{helper}' via decman's builder: {pkg}")
            try:
                self.fpm.install([pkg], force=self.force_build)
            except Exception as e:  # pylint: disable=broad-except
                l.print_warning(f"Failed to install AUR helper '{pkg}': {e}")
                # Fallback path: try building the helper locally via makepkg (no chroot)
                if not self.only_print:
                    self._fallback_install_helper_via_makepkg(helper, pkg)
        else:
            # If FPM is disabled, attempt direct makepkg bootstrap instead of giving up.
            if not self.only_print:
                l.print_summary(
                    f"Bootstrapping AUR helper '{helper}' via makepkg (FPM disabled): {pkg}"
                )
                self._fallback_install_helper_via_makepkg(helper, pkg)
            else:
                l.print_warning(
                    f"AUR helper '{helper}' is not installed and decman FPM is disabled; cannot auto-install helper."
                )

    def _fallback_install_helper_via_makepkg(self, helper: str, pkg: str):
        """Attempt to bootstrap-install an AUR helper without chroot using makepkg.

        Strategy:
        - Clone/refresh the AUR repo to a temp dir
        - Build as the invoking SUDO_USER using makepkg (build only, no install)
        - Install the built package(s) with pacman -U as root
        """
        sudo_user = os.environ.get("SUDO_USER")
        if not sudo_user:
            l.print_warning(
                "Cannot run makepkg fallback because SUDO_USER is not set; skipping helper bootstrap."
            )
            return

        repo_url = f"https://aur.archlinux.org/{pkg}.git"
        # Use /tmp (sticky, user-writable) to avoid permission issues; build as SUDO_USER
        workdir = f"/tmp/decman-{helper}-bootstrap"
        try:
            # If an old root-owned directory exists from a prior attempt, remove it so user can clone
            if os.path.exists(workdir):
                try:
                    st = os.stat(workdir)
                    # If not owned by the target user, remove and reclone as user
                    import pwd as _pwd
                    target_uid = _pwd.getpwnam(sudo_user).pw_uid
                    if st.st_uid != target_uid:
                        shutil.rmtree(workdir, ignore_errors=True)
                except Exception:
                    # If anything goes wrong determining ownership, remove and recreate
                    shutil.rmtree(workdir, ignore_errors=True)

            if not os.path.exists(workdir):
                l.print_info(f"Cloning {pkg} AUR repo to {workdir}...")
                decman.prg(["git", "clone", repo_url, workdir], user=sudo_user)
            else:
                l.print_info(f"Updating existing repo in {workdir}...")
                decman.prg(["git", "-C", workdir, "pull"], user=sudo_user)

            # Build as the invoking user (no install here)
            l.print_info("Building helper package via makepkg (no chroot)...")
            # Ensure BUILDDIR is writable by the user; point it to the repo itself
            decman.prg(["bash", "-lc", f"cd {workdir} && BUILDDIR={workdir} makepkg -s -f --noconfirm"], user=sudo_user)

            # Collect built package files
            built_files = [
                os.path.join(workdir, f)
                for f in os.listdir(workdir)
                if f.endswith(tuple(conf.valid_pkgexts))
            ]
            if not built_files:
                l.print_warning("makepkg did not produce any package files; cannot install helper.")
                return

            l.print_summary(f"Installing helper packages with pacman -U: {', '.join(os.path.basename(f) for f in built_files)}")
            decman.prg(["pacman", "-U", "--noconfirm"] + built_files)
        except Exception as e:  # pylint: disable=broad-except
            l.print_warning(f"Fallback makepkg bootstrap for '{pkg}' failed: {e}")

    def _create_and_remove_files(self):
        l.print_summary("Installing files.")

        all_created = self.source.create_all_files(self.only_print)
        # Optionally add pacman/yay guard wrappers
        all_created.extend(self._maybe_install_pkgmgr_wrappers())
        to_remove = self.source.files_to_remove(self.store, all_created)

        l.print_list("Ensured files are up to date:", all_created, elements_per_line=1)
        l.print_list("Removing files:", to_remove, elements_per_line=1)

        if self.only_print:
            return

        for file in to_remove:
            try:
                os.remove(file)
            except OSError as e:
                l.print_error(f"{e}")
                l.print_warning(f"Failed to remove file: {file}")

        self.store.created_files = all_created

    def _maybe_install_pkgmgr_wrappers(self) -> list[str]:
        """
        Installs pacman/yay guard wrappers into /usr/local/bin if enabled.
        Returns the list of created file paths (for tracking/removal).
        """
        created: list[str] = []
        if self.only_print or not conf.enable_pkgmgr_wrappers:
            return created

        src_path = self.store.source_file or "/path/to/source.py"

        pacman_wrapper_content = (
            "#!/usr/bin/env bash\n"
            "set -euo pipefail\n"
            "PACMAN_BIN=/usr/bin/pacman\n\n"
            "check_tree() {\n"
            "  local p=$PPID\n"
            "  local depth=0\n"
            "  while [[ $p -gt 1 && $depth -lt 12 ]]; do\n"
            "    if grep -qa 'decman' \"/proc/$p/cmdline\" 2>/dev/null; then\n"
            "      return 0\n"
            "    fi\n"
            "    p=$(awk '{print $4}' \"/proc/$p/stat\" 2>/dev/null || echo 1)\n"
            "    depth=$((depth+1))\n"
            "  done\n"
            "  return 1\n"
            "}\n\n"
            "if [[ \"${DECMAN_ALLOW:-}\" == \"1\" ]] || check_tree; then\n"
            "  exec \"$PACMAN_BIN\" \"$@\"\n"
            "fi\n\n"
            "block=false\n"
            "for arg in \"$@\"; do\n"
            "  if [[ \"$arg\" == \"--\" ]]; then break; fi\n"
            "  if [[ \"$arg\" == --sync || \"$arg\" == --remove || \"$arg\" == --upgrade ]]; then\n"
            "    block=true\n"
            "  fi\n"
            "  if [[ \"$arg\" == -* ]]; then\n"
            "    [[ \"$arg\" == *S* ]] && block=true\n"
            "    [[ \"$arg\" == *U* ]] && block=true\n"
            "    [[ \"$arg\" == *R* ]] && block=true\n"
            "  fi\n"
            "done\n\n"
            "if $block; then\n"
            "  cat >&2 <<'EOF'\n"
            "Manual pacman install/remove/upgrade blocked by decman guard (pre-download).\n\n"
            "Please update your decman source and run:\n"
            f"  sudo decman --source {src_path}\n\n"
            "To bypass once (not recommended):\n"
            "  sudo DECMAN_ALLOW=1 pacman <args>\n"
            "EOF\n"
            "  exit 1\n"
            "fi\n\n"
            "exec \"$PACMAN_BIN\" \"$@\"\n"
        )

        yay_wrapper_content = (
            "#!/usr/bin/env bash\n"
            "set -euo pipefail\n"
            "YAY_BIN=/usr/bin/yay\n\n"
            "check_tree() {\n"
            "  local p=$PPID\n"
            "  local depth=0\n"
            "  while [[ $p -gt 1 && $depth -lt 12 ]]; do\n"
            "    if grep -qa 'decman' \"/proc/$p/cmdline\" 2>/dev/null; then\n"
            "      return 0\n"
            "    fi\n"
            "    p=$(awk '{print $4}' \"/proc/$p/stat\" 2>/dev/null || echo 1)\n"
            "    depth=$((depth+1))\n"
            "  done\n"
            "  return 1\n"
            "}\n\n"
            "if [[ \"${DECMAN_ALLOW:-}\" == \"1\" ]] || check_tree; then\n"
            "  exec \"$YAY_BIN\" \"$@\"\n"
            "fi\n\n"
            "block=false\n"
            "for arg in \"$@\"; do\n"
            "  if [[ \"$arg\" == \"--\" ]]; then break; fi\n"
            "  if [[ \"$arg\" == --sync || \"$arg\" == --remove || \"$arg\" == --upgrade ]]; then\n"
            "    block=true\n"
            "  fi\n"
            "  if [[ \"$arg\" == -* ]]; then\n"
            "    [[ \"$arg\" == *S* ]] && block=true\n"
            "    [[ \"$arg\" == *U* ]] && block=true\n"
            "    [[ \"$arg\" == *R* ]] && block=true\n"
            "  fi\n"
            "done\n\n"
            "if $block; then\n"
            "  cat >&2 <<'EOF'\n"
            "Manual yay install/remove/upgrade blocked by decman guard (pre-download).\n\n"
            "Please update your decman source and run:\n"
            f"  sudo decman --source {src_path}\n\n"
            "To bypass once (not recommended):\n"
            "  sudo DECMAN_ALLOW=1 yay <args>\n"
            "EOF\n"
            "  exit 1\n"
            "fi\n\n"
            "exec \"$YAY_BIN\" \"$@\"\n"
        )

        paru_wrapper_content = (
            "#!/usr/bin/env bash\n"
            "set -euo pipefail\n"
            "PARU_BIN=/usr/bin/paru\n\n"
            "check_tree() {\n"
            "  local p=$PPID\n"
            "  local depth=0\n"
            "  while [[ $p -gt 1 && $depth -lt 12 ]]; do\n"
            "    if grep -qa 'decman' \"/proc/$p/cmdline\" 2>/dev/null; then\n"
            "      return 0\n"
            "    fi\n"
            "    p=$(awk '{print $4}' \"/proc/$p/stat\" 2>/dev/null || echo 1)\n"
            "    depth=$((depth+1))\n"
            "  done\n"
            "  return 1\n"
            "}\n\n"
            "if [[ \"${DECMAN_ALLOW:-}\" == \"1\" ]] || check_tree; then\n"
            "  exec \"$PARU_BIN\" \"$@\"\n"
            "fi\n\n"
            "block=false\n"
            "for arg in \"$@\"; do\n"
            "  if [[ \"$arg\" == \"--\" ]]; then break; fi\n"
            "  if [[ \"$arg\" == --sync || \"$arg\" == --remove || \"$arg\" == --upgrade ]]; then\n"
            "    block=true\n"
            "  fi\n"
            "  if [[ \"$arg\" == -* ]]; then\n"
            "    [[ \"$arg\" == *S* ]] && block=true\n"
            "    [[ \"$arg\" == *U* ]] && block=true\n"
            "    [[ \"$arg\" == *R* ]] && block=true\n"
            "  fi\n"
            "done\n\n"
            "if $block; then\n"
            "  cat >&2 <<'EOF'\n"
            "Manual paru install/remove/upgrade blocked by decman guard (pre-download).\n\n"
            "Please update your decman source and run:\n"
            f"  sudo decman --source {src_path}\n\n"
            "To bypass once (not recommended):\n"
            "  sudo DECMAN_ALLOW=1 paru <args>\n"
            "EOF\n"
            "  exit 1\n"
            "fi\n\n"
            "exec \"$PARU_BIN\" \"$@\"\n"
        )

        wrappers = {}
        exe = shutil.which("pacman")
        if exe == "/usr/bin/pacman":
            wrappers["/usr/local/bin/pacman"] = pacman_wrapper_content
        exe = shutil.which("yay")
        if exe == "/usr/bin/yay":
            wrappers["/usr/local/bin/yay"] = yay_wrapper_content
        exe = shutil.which("paru")
        if exe == "/usr/bin/paru":
            wrappers["/usr/local/bin/paru"] = paru_wrapper_content

        for target, content in wrappers.items():
            try:
                file = decman.File(content=content, permissions=0o755)
                file.copy_to(target)
                created.append(target)
            except OSError as e:
                l.print_error(f"{e}")
                l.print_warning(f"Failed to install wrapper: {target}")
        return created

    def _offer_clean_pkg_cache(self):
        """
        Show pacman cache summary and optionally prompt to clean uninstalled/old packages.
        """
        if self.only_print:
            return

        cache_dir = "/var/cache/pacman/pkg"
        try:
            # Get cache size
            result = subprocess.run(
                ["du", "-sh", cache_dir],
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            if result.returncode == 0:
                cache_size = result.stdout.decode().strip().split()[0]
                l.print_summary(f"Package cache size: {cache_size}")

            # Count cached packages
            cache_files = len(
                [
                    f
                    for f in os.listdir(cache_dir)
                    if f.endswith((".pkg.tar.zst", ".pkg.tar.xz", ".pkg.tar.gz", ".pkg.tar"))
                ]
            )
            if cache_files == 0:
                return

            l.print_summary(f"Found {cache_files} cached package file(s).")

            # If configured, clean automatically without prompting
            if conf.auto_clean_pacman_cache:
                decman.prg(["pacman", "-Sc", "--noconfirm"])
                l.print_summary("Package cache cleaned (pacman -Sc).")
                return

            # Otherwise, fall back to previous prompt-based behaviour if enabled
            if conf.prompt_clean_pacman_cache:
                if l.prompt_confirm(
                    "Clean uninstalled and old cached packages? (pacman -Sc)", default=False
                ):
                    decman.prg(["pacman", "-Sc", "--noconfirm"])
                    l.print_summary("Package cache cleaned.")
        except Exception as e:  # pylint: disable=broad-except
            l.print_warning(f"Failed to check/clean package cache: {e}")

    def _enable_units(self):
        to_enable = self.source.units_to_enable(self.store)
        l.print_list("Enabling systemd units:", to_enable)
        if to_enable:
            l.print_info("Enabled systemd units won't be started automatically.")
        if not self.only_print:
            self.systemctl.enable_units(to_enable)

        user_units_to_enable = self.source.user_units_to_enable(self.store)
        for user, units in user_units_to_enable.items():
            l.print_list(f"Enabling systemd units for {user}:", units)
            if not self.only_print:
                self.systemctl.enable_user_units(units, user)

    def _run_modules(self):
        l.print_summary("Running on enable hooks.")
        if not self.only_print:
            self.source.run_on_enable(self.store)

        l.print_summary("Running after version change hooks.")
        if not self.only_print:
            self.source.run_after_version_change(self.store)

        l.print_summary("Running on disable hooks.")
        if not self.only_print:
            self.source.run_on_disable(self.store)

        l.print_summary("Running after update hooks.")
        if not self.only_print:
            self.source.run_after_update()

    def _ensure_qml_niri(self):
        """Install or build niri-qml depending on configuration.

        Modes controlled by conf.qml_niri_install: "off" | "aur" | "source".
        - aur: install AUR package via configured helper or FPM
        - source: clone/update, build with 'just build', and install into QT_INSTALL_QML
        """
        mode = getattr(conf, "qml_niri_install", "off")
        if self.only_print or mode == "off":
            return

        if mode == "aur":
            pkg = getattr(conf, "qml_niri_aur_package", None)
            if not pkg:
                l.print_warning("qml_niri_install is 'aur' but qml_niri_aur_package is not set; skipping.")
                return

            # Prefer helper if configured and available
            self._ensure_aur_helper_installed_if_needed()
            helper_exe = self._resolve_aur_helper_exe()
            if conf.use_aur_helper_for_aur and helper_exe is not None:
                sudo_user = os.environ.get("SUDO_USER")
                if sudo_user:
                    l.print_summary(f"Installing niri-qml AUR package with {helper_exe}: {pkg}")
                    decman.prg([helper_exe, "-S", "--needed", pkg], user=sudo_user)
                    return
                l.print_warning("SUDO_USER not set; cannot run AUR helper as a regular user. Falling back to FPM if enabled.")

            if conf.enable_fpm and self.update_foreign_packages:
                l.print_summary(f"Installing niri-qml AUR package via decman's builder: {pkg}")
                try:
                    self.fpm.install([pkg], force=self.force_build)
                except Exception as e:  # pylint: disable=broad-except
                    l.print_warning(f"Failed to install niri-qml AUR package '{pkg}': {e}")
            else:
                l.print_warning("Cannot install niri-qml: no AUR helper available and FPM disabled.")
            return

        if mode == "source":
            repo = getattr(conf, "qml_niri_repo_url", "")
            local = getattr(conf, "qml_niri_local_clone", "/usr/local/src/qml-niri")
            build_dir = getattr(conf, "qml_niri_build_dir", f"{local}/build")
            marker = getattr(conf, "qml_niri_install_marker", "/usr/local/share/qml-niri-installed")

            try:
                import pathlib
                l.print_summary("Ensuring niri-qml (source build)...")

                # Clone or update repo
                if os.path.exists(local):
                    l.print_info(f"Updating {local}...")
                    subprocess.run(["git", "-C", local, "pull"], check=True, capture_output=True)
                else:
                    l.print_info(f"Cloning repo {repo} to {local}...")
                    os.makedirs(os.path.dirname(local), exist_ok=True)
                    subprocess.run(["git", "clone", repo, local], check=True)

                # Get current commit
                current_commit = subprocess.run(["git", "-C", local, "rev-parse", "HEAD"], check=True, stdout=subprocess.PIPE).stdout.decode().strip()

                # Read installed commit
                installed_commit = None
                if os.path.exists(marker):
                    try:
                        with open(marker, "r", encoding="utf-8") as f:
                            installed_commit = f.read().strip()
                    except Exception:  # pylint: disable=broad-except
                        installed_commit = None

                # Build if missing or commit differs
                if installed_commit != current_commit:
                    l.print_info("Building niri-qml (this may take a minute)...")
                    subprocess.run(["just", "build"], cwd=local, check=True)

                    # Determine Qt QML install path
                    qml_path = subprocess.run(["qmake6", "-query", "QT_INSTALL_QML"], check=True, stdout=subprocess.PIPE).stdout.decode().strip()
                    niri_plugin_src = os.path.join(build_dir, "Niri")
                    niri_plugin_dst = os.path.join(qml_path, "Niri")

                    if os.path.exists(niri_plugin_src):
                        if os.path.exists(niri_plugin_dst):
                            shutil.rmtree(niri_plugin_dst)
                        l.print_info(f"Installing qml-niri plugin to {niri_plugin_dst}...")
                        shutil.copytree(niri_plugin_src, niri_plugin_dst)
                        with open(marker, "w", encoding="utf-8") as f:
                            f.write(current_commit)
                        l.print_summary(f"qml-niri plugin installed to {niri_plugin_dst}")
                    else:
                        l.print_warning(f"Build output not found: {niri_plugin_src}")
                else:
                    l.print_info("qml-niri already up-to-date; skipping build.")
            except subprocess.CalledProcessError as e:
                l.print_warning(f"Failed to build/install qml-niri: {e}")
            except Exception as e:  # pylint: disable=broad-except
                l.print_warning(f"Failed to ensure qml-niri: {e}")

    def _offer_remove_orphans(self):
        """
        Interactively offer to remove orphaned packages.
        """
        orphans = self.pacman.list_orphans()
        if not orphans:
            return
        l.print_list(
            "Orphan packages detected (installed as deps, no longer required):",
            orphans,
        )
        # If configured, remove orphans automatically without prompting
        if conf.auto_remove_orphans:
            l.print_summary("Removing orphan packages automatically.")
            self.pacman.remove_orphans(orphans)
            return

        if l.prompt_confirm("Remove these orphan packages now?", default=False):
            self.pacman.remove_orphans(orphans)


def _resolve_source() -> l.Source:
    enabled_systemd_user_units = {}
    for user, units in decman.enabled_systemd_user_units.items():
        enabled_systemd_user_units[user] = set(units)

    return l.Source(
        pacman_packages=set(decman.packages),
        aur_packages=set(decman.aur_packages),
        user_packages=set(decman.user_packages),
        ignored_packages=set(decman.ignored_packages),
        systemd_units=set(decman.enabled_systemd_units),
        systemd_user_units=enabled_systemd_user_units,
        files=decman.files,
        directories=decman.directories,
        modules=set(decman.modules),
    )


def _is_root() -> bool:
    return os.geteuid() == 0
